package br.edu.ifsp.spo.lp2a4.Juntos.Somos.Mais;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuntosSomosMaisApplicationTests {

	@Test
	void contextLoads() {
	}

}
