package br.edu.ifsp.spo.lp2a4.Juntos.Somos.Mais;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuntosSomosMaisApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuntosSomosMaisApplication.class, args);
	}

}
