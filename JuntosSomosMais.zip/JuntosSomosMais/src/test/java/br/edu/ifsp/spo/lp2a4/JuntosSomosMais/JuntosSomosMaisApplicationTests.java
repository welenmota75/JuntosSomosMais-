package br.edu.ifsp.spo.lp2a4.JuntosSomosMais;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuntosSomosMaisApplicationTests {

	@Test
	void contextLoads() {
	}

}
