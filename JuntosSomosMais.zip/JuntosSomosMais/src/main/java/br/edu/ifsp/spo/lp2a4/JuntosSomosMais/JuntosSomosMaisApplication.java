package br.edu.ifsp.spo.lp2a4.JuntosSomosMais;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuntosSomosMaisApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuntosSomosMaisApplication.class, args);
	}

}
